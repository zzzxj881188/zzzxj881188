const { spawn } = require('child_process');
const http = require("http");
let server = http.createServer();
const port = 2096;
const express = require("express");
const app = express();

const child = spawn('node', [__dirname + '/WS_chat/server.js']);
child.stdout.on('data', (data) => console.log(`Socket.io server log: ${data}`));
child.stderr.on('data', (data) => console.error(`Socket.io server error: ${data}`));
child.on('close', (code) => console.log(`child process exited with code ${code}`));

server.on("request", app);

app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(express.urlencoded({ extended: true }));

app.get("/tw", async function(req, res) {
    if(!req.query?.tiktok) return res.status(400).json({ status: 400, message: "没有提供蒂克特", auth: false });

    res.render(__dirname + "/views/territory_war/index", {
        WSdomain: "http://localhost:2087",
        tiktok: req.query.tiktok
    });
});

return new Promise((resolve, reject) => {
    console.log("Starting web server...");
    server.listen(port, function() {
        resolve(true);
        console.log("Web server started");
        console.log("http://localhost:" + port);
    });
});