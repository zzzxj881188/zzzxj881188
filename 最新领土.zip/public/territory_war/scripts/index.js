let wss_exs, wssx;
let userId = "";
let ccxx = false;
let connectionf;

// export function connect(WSdomain, tiktok) {
//     ccxx = true;
//     $("#controlddd").remove();
//     $("#pageContainer").css("visibility", "visible");
//     start();
//     const pic = "https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/c18ca3a80f2e403f66ad26250c1e6bcb.webp?x-expires=1686218400&x-signature=0iGuJOiu26Ad5znuh2FfdUyBVLk%3D";
//     onjoin1({ uniqueId: "xxx", profilePictureUrl: pic });

//     setInterval(() => {
//         let random = Math.floor(Math.random() * 5) + 1;
//         const randomString = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
//         switch (random) {
//             case 1:
//                 onjoin1({ uniqueId: randomString, profilePictureUrl: pic });
//                 break;
//             case 2:
//                 onjoin2({ uniqueId: randomString, profilePictureUrl: pic });
//                 break;
//             case 3:
//                 onjoin3({ uniqueId: randomString, profilePictureUrl: pic });
//                 break;
//             case 4:
//                 onjoin4({ uniqueId: randomString, profilePictureUrl: pic });
//                 break;
//             case 5:
//                 onjoin5({ uniqueId: randomString, profilePictureUrl: pic });
//                 break;
//         };
//     }, 500);
// };
export function connect(WSdomain, tiktok) {
    let uniqueId = tiktok.startsWith('@') ? tiktok.substring(1) : tiktok;
    connectionf = new Websocket(WSdomain !== 'undefined' ? WSdomain : "https://tiktok-chat-reader.zerody.one/");

    if (uniqueId != undefined || uniqueId != null) {
        connectionf.connect(uniqueId, {
            enableExtendedGiftInfo: true
        }).then(state => {
            let cxd = true;
            ccxx = true;
            $("#controlddd").remove();
            $("#pageContainer").css("visibility", "visible");
            start();

            connectionf.on('gift', (data) => {
                // console.log(data);
                if (cxd) ongift(data);
            })
            connectionf.on('like', (data) => {
                // console.log(data);
                if (cxd) onlike(data);
            })
            connectionf.on('follow', (data) => {
                // console.log(data);
                if (cxd) onfollow(data);
            })
            connectionf.on('share', (data) => {
                // console.log(data);
                if (cxd) onshare(data);
            })
            connectionf.on('chat', (data) => {
                // console.log(data);
                if (cxd) {
                    let arrx = data.comment.split(" ");
                    if (arrx.length > 0) {
                        let codexx = arrx[0];
                        
                        switch (codexx) {
                            case "1":
                                onjoin1(data);
                                break;
                            case "2":
                                onjoin2(data);
                                break;
                            case "3":
                                onjoin3(data);
                                break;
                            case "4":
                                onjoin4(data);
                                break;
                            case "5":
                                onjoin5(data);
                                break;
                            default: break;
                        }
                    }
                }
            })
        }).catch(errorMessage => {
            if (errorMessage.toLowerCase().includes("live has ended")) $("#infobo").text("PLEASE START LIVE FIRST THEN GAME!");
            else $("#infobo").text(errorMessage);
        })

    } else $("#infobo").text("PLEASE ENTER USERNAME!");
}

class Websocket {
    constructor(backendUrl) {
        this.socket = io(backendUrl);
        this.uniqueId = null;
        this.options = null;

        this.socket.on('connect', () => {
            console.info("Socket connected!");

            // Reconnect to streamer if uniqueId already set
            if (this.uniqueId) {
                this.setUniqueId();
            }
        })

        this.socket.on('disconnect', () => {
            console.warn("Socket disconnected!");
        })

        this.socket.on('streamEnd', () => {
            onstreamEnd();
            console.warn("LIVE has ended!");
            this.uniqueId = null;
        })

        this.socket.on('tiktokDisconnected', (errMsg) => {
            console.warn(errMsg);
            if (errMsg && errMsg.includes('LIVE has ended')) {
                onstreamEnd();
                this.uniqueId = null;
            }
        });
    }

    connect(uniqueId, options) {
        this.uniqueId = uniqueId;
        this.options = options || {};

        this.setUniqueId();

        return new Promise((resolve, reject) => {
            // this.socket.once('tiktokConnected', (x) => {
            //     resolve(x);
            //     setTimeout(() => {
            //         const pic = "https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/c18ca3a80f2e403f66ad26250c1e6bcb.jpeg?x-expires=1687093200&x-signature=1Sh2EWMnYQnRjg63woYZPWS2RVc%3D";
            //         onjoin1({ uniqueId: "xxx", profilePictureUrl: pic });
            //         onjoin5({ uniqueId: "yyy", profilePictureUrl: pic });

            //         setTimeout(() => {
            //             ongift({
            //                 giftId: 5879,
            //                 uniqueId: "xxx",
            //                 profilePictureUrl: pic,
            //             })
            //             setTimeout(() => {
            //                 ongift({
            //                     giftId: 5660,
            //                     uniqueId: "yyy",
            //                     profilePictureUrl: pic,
            //                 })
            //             , 2000});
            //         }, 5000);
            //     }, 10000);
            // });
            this.socket.once('tiktokConnected', resolve);
            this.socket.once('tiktokDisconnected', reject);

            setTimeout(() => {
                reject('Connection Timeout');
            }, 15000)
        })
    }

    setUniqueId() {
        this.socket.emit('setUniqueId', this.uniqueId, this.options);
    }

    on(eventName, eventHandler) {
        this.socket.on(eventName, eventHandler);
    }
}

function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }

    return result + userId;
}

function onjoin1(config) {
    join(config.uniqueId, 1, config.profilePictureUrl);
};

function onjoin2(config) {
    join(config.uniqueId, 2, config.profilePictureUrl);
};

function onjoin3(config) {
    join(config.uniqueId, 3, config.profilePictureUrl);
};

function onjoin4(config) {
    join(config.uniqueId, 4, config.profilePictureUrl);
};

function onjoin5(config) {
    join(config.uniqueId, 5, config.profilePictureUrl);
};

function onjoinRng(updated) {
    joinRandom(updated.uniqueId, updated.pic);
};

function ongift(data) {
    switch (data.giftId) {
        case 5655: { // Rose
            moreSpeed(data.uniqueId, 0.02 * data.repeatCount, data.profilePictureUrl);
            // speedForTeam(data.uniqueId, 1 * data.repeatCount * 0.1);
            break;
        }
        case 5760: { // Haltère
            for (let xc = 0; xc < 1; xc++) {
                moreCircles(data.uniqueId, data.profilePictureUrl);
            }
            // speedForTeam(data.uniqueId, 1 * data.repeatCount * 0.1);
            break;
        }
        case 5487: { // Hand with heart
            moreSpeed(data.uniqueId, 5 * data.repeatCount, data.profilePictureUrl);
            // speedForTeam(data.uniqueId, 5 * data.repeatCount * 0.1);
            break;
        }
        case 37: { // Panda
            for (let dc = 0; dc < 5; dc++) {
                console.log("Panda: ", dc);
                moreCircles(data.uniqueId, data.profilePictureUrl);
            }
            // speedForTeam(data.uniqueId, 5 * data.repeatCount * 0.1);
            break;
        }
        case 5585: { // Confetti
            moreSpeed(data.uniqueId, 100, data.profilePictureUrl);
            // speedForTeam(data.uniqueId, 100 * data.repeatCount * 0.1);
            break;
        }
        case 5660: {// Heart
            for (let mm = 0; mm < 100; mm++) {
                console.log("Heart: ", mm);
                moreCircles(data.uniqueId, data.profilePictureUrl);
            }
            // speedForTeam(data.uniqueId, 100 * data.repeatCount * 0.1);
            break;
        }
        case 5879: { // Donuts
            for (let xx = 0; xx < 30; xx++) {
                console.log("Donuts: ", xx);
                moreCircles(data.uniqueId, data.profilePictureUrl);
            }
            // speedForTeam(data.uniqueId, 30 * data.repeatCount * 0.1);
            break
        };
        case 6070: { // Mirror
            if (gameRunning) {
                // if (userPlaying(data.uniqueId) === false) {
                //   let gitOpts = rng(1, 5);
                //   for (; isTeamAlive(gitOpts) === false;) {
                //     gitOpts = rng(1, 5);
                //   }
                //   players.push({
                //     name: data.uniqueId,
                //     speed: baseSpeed,
                //     team: gitOpts,
                //     appliedLikeSpeed: false,
                //     pic: data.profilePictureUrl,
                //     shareBalls: 0,
                //     appliedFollowBalls: false,
                //     isKing: false
                //   });
                //   spawn(data.uniqueId, baseSpeed, gitOpts, data.profilePictureUrl);
                // }
                let teamResult = getPlayer(data.uniqueId);
                if (teamResult != null) sabotageSelect(teamResult.team);
            }
            break;
        };
        case 5897: { // SURPRISE (cygne)
            moreSpeed(data.uniqueId, 699, data.profilePictureUrl);
            for (let i = 0; i < 25; i++) {
                moreCircles(data.uniqueId, data.profilePictureUrl);
            }
            // speedForTeam(data.uniqueId, 699 * data.repeatCount * 0.1);
            king(data.uniqueId, data.profilePictureUrl);
            break;
        };
        default: {
            // moreSpeed(data.uniqueId, 0.2 * data.repeatCount, data.profilePictureUrl);
            break;
        };
    }
};

let usersLikes = new Map();

function onlike(data) {
    if (gameRunning) {
        let player = getPlayer(data.uniqueId);
        if (player != null) {
            let userLikes = usersLikes.get(data.uniqueId);
            if(!userLikes) return usersLikes.set(data.uniqueId, 1);
            else {
                usersLikes.set(data.uniqueId, usersLikes.get(data.uniqueId) + 1);
                userLikes = usersLikes.get(data.uniqueId);

                if(userLikes == 20) {
                    moreSpeed(data.uniqueId, 3, data.profilePictureUrl);
                } else return;
            };
        };
    };
};

function onfollow(data) {
    if (gameRunning) {
        if (userPlaying(data.uniqueId) === false) {
            let gitOpts = rng(1, 5);
            for (; isTeamAlive(gitOpts) === false;) {
                gitOpts = rng(1, 5);
            }
            players.push({
                name: data.uniqueId,
                speed: baseSpeed,
                team: gitOpts,
                appliedLikeSpeed: false,
                pic: data.profilePictureUrl,
                shareBalls: 0,
                appliedFollowBalls: false,
                isKing: false
            });
            spawn(data.uniqueId, baseSpeed, gitOpts, data.profilePictureUrl);
        }
        let player = getPlayer(data.uniqueId);
        if (player != null && player.appliedFollowBalls === false) {
            applyFollowBalls(data.uniqueId);
            moreCircles(data.uniqueId, data.profilePictureUrl);
        }
    }
}

function onshare(data) {
    if (gameRunning) {
        if (userPlaying(data.uniqueId) === false) {
            let gitOpts = rng(1, 5);
            for (; isTeamAlive(gitOpts) === false;) {
                gitOpts = rng(1, 5);
            }
            players.push({
                name: data.uniqueId,
                speed: baseSpeed,
                team: gitOpts,
                appliedLikeSpeed: false,
                pic: data.profilePictureUrl,
                shareBalls: 0,
                appliedFollowBalls: false,
                isKing: false
            });
            spawn(data.uniqueId, baseSpeed, gitOpts, data.profilePictureUrl);
        }
        let player = getPlayer(data.uniqueId);
        if (player != null && player.shareBalls < 1) {
            applyShareBalls(data.uniqueId);
            moreCircles(data.uniqueId, data.profilePictureUrl);
        }
    }
}

function onstreamEnd() {
    document.getElementById("connectButton").style.backgroundColor = "grey";
    document.getElementById("connectButton").innerHTML = "流动结束";
}

var Engine = Matter.Engine;
var Render = Matter.Render;
var Runner = Matter.Runner;
var Bodies = Matter.Bodies;
var Composite = Matter.Composite;
var Body = Matter.Body;
var Events = Matter.Events;
var Detector = Matter.Detector;
var Vector = Matter.Vector;
var engine = Engine.create({
    gravity: {
        x: 0,
        y: 0
    }
});
engine.positionIterations = 20;
engine.velocityIterations = 20;
Engine.update(engine, 1);
var render = Render.create({
    element: document.getElementById("canvasContainer"),
    engine: engine,
    canvas: document.getElementById("canvas"),
    options: {
        width: 1080,
        height: 1284,
        wireframes: false,
        background: "#cccccc"
    }
});

let width = 1020;
let height = 1224;
let borderSize = 2;
let blockWidth = width / 50 - borderSize;
let blockColor = "#CCCCCC";
let blockBorderColor = "#666666";
let gameSeconds = 900;
let baseSpeed = 1;
let maxSpeed = 20;
let ballSize = 50;
let team1Color = "#2465D3";
let team1Bg = "#2E6DDC";
let team2Color = "#DD2020";
let team2Bg = "#E33B3B";
let team3Color = "#E3B83B";
let team3Bg = "#E3B93B";
let team4Color = "#5ADD40";
let team4Bg = "#69E052";
let team5Color = "#B72CDD";
let team5Bg = "#BD3EE0";
let borderColor = "#999999";
let totalPoints = 3000;
let bluep = 0;
let greenp = 0;
let yellowp = 0;
let redp = 0;
let purplep = 0;
var grounds = new Array;
var backgrounds = new Array;
var players = new Array;
var team1 = new Array;
var team2 = new Array;
var team3 = new Array;
var team4 = new Array;
var team5 = new Array;
var teams = [
    {
        id: 1,
        tag: "Blue",
        lives: false,
        sabotaged: false
    }, 
    {
        id: 2,
        tag: "Red",
        lives: false,
        sabotaged: false
    }, 
    {
        id: 3,
        tag: "Yellow",
        lives: false,
        sabotaged: false
    }, 
    {
        id: 4,
        tag: "Green",
        lives: false,
        sabotaged: false
    }, 
    {
        id: 5,
        tag: "Purple",
        lives: false,
        sabotaged: false
    }
];

function initializeWorld() {
    resetWorld();
    addGrounds();
    addBackgrounds();
}

function resetWorld() {
    Composite.clear(engine.world);

    document.getElementById("team1Castle").style.display = "block";
    document.getElementById("team2Castle").style.display = "block";
    document.getElementById("team3Castle").style.display = "block";
    document.getElementById("team4Castle").style.display = "block";
    document.getElementById("team5Castle").style.display = "block";

    grounds = [];
    backgrounds = [];
    players = [];
    team1 = [];
    team2 = [];
    team3 = [];
    team4 = [];
    team5 = [];
    bluep = 0;
    greenp = 0;
    yellowp = 0;
    redp = 0;
    purplep = 0;
    usersLikes = new Map();
    
    document.getElementById("countdown").innerHTML = gameSeconds;
    document.getElementById("blue_percentage").innerHTML = "";
    document.getElementById("green_percentage").innerHTML = "";
    document.getElementById("yellow_percentage").innerHTML = "";
    document.getElementById("red_percentage").innerHTML = "";
    document.getElementById("purple_percentage").innerHTML = "";
}

function addGrounds() {
    grounds.push(Bodies.rectangle(540, 0, 1080, 60, {
        isStatic: true,
        render: {
            fillStyle: "#2d2d35"
        }
    }));
    grounds.push(Bodies.rectangle(540, 1280, 1080, 60, {
        isStatic: true,
        render: {
            fillStyle: "#2d2d35"
        }
    }));
    grounds.push(Bodies.rectangle(0, 640, 60, 1280, {
        isStatic: true,
        render: {
            fillStyle: "#2d2d35"
        }
    }));
    grounds.push(Bodies.rectangle(1080, 640, 60, 1280, {
        isStatic: true,
        render: {
            fillStyle: "#2d2d35"
        }
    }));
    Composite.add(engine.world, grounds);
}

function addBackgrounds() {
    let label12 = 0;
    let fillColors = blockColor;
    for (let i = 0; i < 50; i++) {
        for (let x = 0; x < 60; x++) {
            label12 = 0;
            fillColors = blockColor;
            backgrounds.push(Bodies.rectangle(31 + blockWidth / 2 + i * blockWidth + i * borderSize, 31 + blockWidth / 2 + x * blockWidth + x * borderSize, blockWidth, blockWidth, {
                isStatic: true,
                collisionFilter: {
                    group: label12
                },
                render: {
                    fillStyle: fillColors,
                    strokeStyle: blockBorderColor,
                    lineWidth: borderSize
                }
            }));
        }
    }
    Composite.add(engine.world, backgrounds);
}

Render.run(render);
var runner = Runner.create();
Runner.run(runner, engine);

function joinButton() {
    join(document.getElementById("testUser").value, parseInt(document.getElementById("testTeam").value), "tw/img/1.png");
}

/**
 * @param {string} collectionName
 * @param {number} data
 * @param {string} callback
 * @return {undefined}
 */
function join(collectionName, data, callback) {
    if (gameRunning && userPlaying(collectionName) === false && isTeamAlive(data)) {
        players.push({
            name: collectionName,
            speed: baseSpeed,
            team: data,
            appliedLikeSpeed: false,
            pic: callback,
            shareBalls: 0,
            appliedFollowBalls: false,
            isKing: false
        });
        spawn(collectionName, baseSpeed, data, callback);
    }
}

/**
 * @param {string} crypt
 * @param {string} fn
 * @return {undefined}
 */
function joinRandom(crypt, fn) {
    if (gameRunning) {
        if (userPlaying(crypt) === false) {
            let gitOpts = rng(1, 5);
            for (; isTeamAlive(gitOpts) === false;) {
                gitOpts = rng(1, 5);
            }
            players.push({
                name: crypt,
                speed: baseSpeed,
                team: gitOpts,
                appliedLikeSpeed: false,
                pic: fn,
                shareBalls: 0,
                appliedFollowBalls: false,
                isKing: false
            });
            spawn(crypt, baseSpeed, gitOpts, fn);
        }
    }
}

/**
 * @param {string} id
 * @return {?}
 */
function userPlaying(id) {
    let userPlaying = false;
    for (let i = 0; i < players.length; i++) {
        if (players[i].name == id) {
            userPlaying = true;
            break;
        }
    }
    return userPlaying;
}

function buttonMoreCircles() {
    for (let i = 0; i < 4; i++) {
        moreCircles(document.getElementById("testUser").value, "tw/img/1.png");
    }
}

/**
 * @param {string} player
 * @param {string} callback
 * @return {undefined}
 */
function moreCircles(player, callback) {
    if (gameRunning) {
        // if (userPlaying(player) === false) {
        //   let gitOpts = rng(1, 5);
        //   for (; isTeamAlive(gitOpts) == false;) {
        //     gitOpts = rng(1, 5);
        //   }
        //   players.push({
        //     name: player,
        //     speed: baseSpeed,
        //     team: gitOpts,
        //     appliedLikeSpeed: false,
        //     pic: callback,
        //     shareBalls: 0,
        //     appliedFollowBalls: false,
        //     isKing: false
        //   });
        //   spawn(player, baseSpeed, gitOpts, callback);
        // }
        let options = getPlayer(player);
        if (options != null && isTeamAlive(options.team)) {
            spawn(options.name, options.speed, options.team, callback);
        }
    }
}

/**
 * @param {string} id
 * @return {?}
 */
function getPlayer(id) {
    let player = null;
    for (let i = 0; i < players.length; i++) {
        if (players[i].name == id) {
            player = players[i];
            break;
        }
    }
    return player;
}

/**
 * @param {?} AnimName
 * @return {undefined}
 */
function applyLikeSpeed(AnimName) {
    for (let i = 0; i < players.length; i++) {
        if (players[i].name == AnimName) {
            players[i].speed += 20;
            break;
        }
    }
}

/**
 * @param {?} AnimName
 * @return {undefined}
 */
function applyShareBalls(AnimName) {
    for (let i = 0; i < players.length; i++) {
        if (players[i].name == AnimName) {
            players[i].shareBalls += 1;
            break;
        }
    }
}

/**
 * @param {?} AnimName
 * @return {undefined}
 */
function applyFollowBalls(AnimName) {
    for (let i = 0; i < players.length; i++) {
        if (players[i].name == AnimName) {
            players[i].appliedFollowBalls = true;
            break;
        }
    }
}

var sabotageTimeouts = [null, null, null, null, null];

/**
 * @param {?} leavingUserId
 * @return {undefined}
 */
function sabotageSelect(leavingUserId) {
    if (gameRunning) {
        sortedPointsList = pointsList.slice().sort((a, b) => {
            return b.points - a.points;
        });
        if (sabotageTimeouts[sortedPointsList[0].id - 1] == null && isTeamAlive(sortedPointsList[0].id) && sortedPointsList[0].id != leavingUserId) {
            sabotage(sortedPointsList[0].id);
        } else {
            if (sabotageTimeouts[sortedPointsList[1].id - 1] == null && isTeamAlive(sortedPointsList[1].id) && sortedPointsList[1].id != leavingUserId) {
                sabotage(sortedPointsList[1].id);
            } else {
                if (sabotageTimeouts[sortedPointsList[2].id - 1] == null && isTeamAlive(sortedPointsList[2].id) && sortedPointsList[2].id != leavingUserId) {
                    sabotage(sortedPointsList[2].id);
                } else {
                    if (sabotageTimeouts[sortedPointsList[3].id - 1] == null && isTeamAlive(sortedPointsList[3].id) && sortedPointsList[3].id != leavingUserId) {
                        sabotage(sortedPointsList[3].id);
                    } else {
                        if (sabotageTimeouts[sortedPointsList[4].id - 1] == null && isTeamAlive(sortedPointsList[4].id) && sortedPointsList[4].id != leavingUserId) {
                            sabotage(sortedPointsList[4].id);
                        } else {
                            if (isTeamAlive(sortedPointsList[0].id) && sortedPointsList[0].id != leavingUserId) {
                                sabotage(sortedPointsList[0].id);
                            } else {
                                if (isTeamAlive(sortedPointsList[1].id) && sortedPointsList[1].id != leavingUserId) {
                                    sabotage(sortedPointsList[1].id);
                                } else {
                                    if (isTeamAlive(sortedPointsList[2].id) && sortedPointsList[2].id != leavingUserId) {
                                        sabotage(sortedPointsList[2].id);
                                    } else {
                                        if (isTeamAlive(sortedPointsList[3].id) && sortedPointsList[3].id != leavingUserId) {
                                            sabotage(sortedPointsList[3].id);
                                        } else {
                                            if (isTeamAlive(sortedPointsList[4].id) && sortedPointsList[4].id != leavingUserId) {
                                                sabotage(sortedPointsList[4].id);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * @param {number} dst_square
 * @return {undefined}
 */
function sabotage(dst_square) {
    if (gameRunning) {
        setTeamSabotaged(dst_square, true);
        switch (dst_square) {
            case 1:
                team1.forEach((chart) => {
                    Body.scale(chart.body, 0.8, 0.8);
                    chart.body.render.sprite.xScale = 0.8;
                    chart.body.render.sprite.yScale = 0.8;
                });
                break;
            case 2:
                team2.forEach((t) => {
                    if (getPlayer(t.name).isKing) {
                        Body.scale(t.body, 1, 1);
                        t.body.render.sprite.xScale = 1;
                        t.body.render.sprite.yScale = 1;
                    } else {
                        Body.scale(t.body, 0.8, 0.8);
                        t.body.render.sprite.xScale = 0.8;
                        t.body.render.sprite.yScale = 0.8;
                    }
                });
                break;
            case 3:
                team3.forEach((t) => {
                    if (getPlayer(t.name).isKing) {
                        Body.scale(t.body, 1, 1);
                        t.body.render.sprite.xScale = 1;
                        t.body.render.sprite.yScale = 1;
                    } else {
                        Body.scale(t.body, 0.8, 0.8);
                        t.body.render.sprite.xScale = 0.8;
                        t.body.render.sprite.yScale = 0.8;
                    }
                });
                break;
            case 4:
                team4.forEach((t) => {
                    if (getPlayer(t.name).isKing) {
                        Body.scale(t.body, 1, 1);
                        t.body.render.sprite.xScale = 1;
                        t.body.render.sprite.yScale = 1;
                    } else {
                        Body.scale(t.body, 0.8, 0.8);
                        t.body.render.sprite.xScale = 0.8;
                        t.body.render.sprite.yScale = 0.8;
                    }
                });
                break;
            case 5:
                team5.forEach((t) => {
                    if (getPlayer(t.name).isKing) {
                        Body.scale(t.body, 1, 1);
                        t.body.render.sprite.xScale = 1;
                        t.body.render.sprite.yScale = 1;
                    } else {
                        Body.scale(t.body, 0.8, 0.8);
                        t.body.render.sprite.xScale = 0.8;
                        t.body.render.sprite.yScale = 0.8;
                    }
                });
                break;
            default:
                team1.forEach((t) => {
                    if (getPlayer(t.name).isKing) {
                        Body.scale(t.body, 1, 1);
                        t.body.render.sprite.xScale = 1;
                        t.body.render.sprite.yScale = 1;
                    } else {
                        Body.scale(t.body, 0.8, 0.8);
                        t.body.render.sprite.xScale = 0.8;
                        t.body.render.sprite.yScale = 0.8;
                    }
                });
                break;
        }
        if (sabotageTimeouts[dst_square - 1] != null) {
            clearTimeout(sabotageTimeouts[dst_square - 1]);
        }
        sabotageTimeouts[dst_square - 1] = setTimeout(() => {
            setTeamSabotaged(dst_square, false);
            switch (dst_square) {
                case 1:
                    team1.forEach((t) => {
                        if (getPlayer(t.name).isKing) {
                            Body.scale(t.body, 1.4, 1.4);
                            t.body.render.sprite.xScale = 1.4;
                            t.body.render.sprite.yScale = 1.4;
                        } else {
                            Body.scale(t.body, 1, 1);
                            t.body.render.sprite.xScale = 1;
                            t.body.render.sprite.yScale = 1;
                        }
                    });
                    break;
                case 2:
                    team2.forEach((t) => {
                        if (getPlayer(t.name).isKing) {
                            Body.scale(t.body, 1.4, 1.4);
                            t.body.render.sprite.xScale = 1.4;
                            t.body.render.sprite.yScale = 1.4;
                        } else {
                            Body.scale(t.body, 1, 1);
                            t.body.render.sprite.xScale = 1;
                            t.body.render.sprite.yScale = 1;
                        }
                    });
                    break;
                case 3:
                    team3.forEach((t) => {
                        if (getPlayer(t.name).isKing) {
                            Body.scale(t.body, 1.4, 1.4);
                            t.body.render.sprite.xScale = 1.4;
                            t.body.render.sprite.yScale = 1.4;
                        } else {
                            Body.scale(t.body, 1, 1);
                            t.body.render.sprite.xScale = 1;
                            t.body.render.sprite.yScale = 1;
                        }
                    });
                    break;
                case 4:
                    team4.forEach((t) => {
                        if (getPlayer(t.name).isKing) {
                            Body.scale(t.body, 1.4, 1.4);
                            t.body.render.sprite.xScale = 1.4;
                            t.body.render.sprite.yScale = 1.4;
                        } else {
                            Body.scale(t.body, 1, 1);
                            t.body.render.sprite.xScale = 1;
                            t.body.render.sprite.yScale = 1;
                        }
                    });
                    break;
                case 5:
                    team5.forEach((t) => {
                        if (getPlayer(t.name).isKing) {
                            Body.scale(t.body, 1.4, 1.4);
                            t.body.render.sprite.xScale = 1.4;
                            t.body.render.sprite.yScale = 1.4;
                        } else {
                            Body.scale(t.body, 1, 1);
                            t.body.render.sprite.xScale = 1;
                            t.body.render.sprite.yScale = 1;
                        }
                    });
                    break;
                default:
                    team1.forEach((t) => {
                        if (getPlayer(t.name).isKing) {
                            Body.scale(t.body, 1.4, 1.4);
                            t.body.render.sprite.xScale = 1.4;
                            t.body.render.sprite.yScale = 1.4;
                        } else {
                            Body.scale(t.body, 1, 1);
                            t.body.render.sprite.xScale = 1;
                            t.body.render.sprite.yScale = 1;
                        }
                    });
                    break;
            }
            sabotageTimeouts[dst_square - 1] = null;
        }, 10000);
    }
}

function buttonMoreSpeed() {
    moreSpeed(document.getElementById("testUser").value, 1, "tw/img/1.png");
}

/**
 * @param {string} uniqueId
 * @param {number} speed
 * @param {string} pic
 * @return {undefined}
 */
function moreSpeed(uniqueId, speed, pic) {
    if (gameRunning) {
        // if (userPlaying(uniqueId) === false) {
        //   let gitOpts = rng(1, 5);
        //   for (; isTeamAlive(gitOpts) == false;) {
        //     gitOpts = rng(1, 5);
        //   }
        //   players.push({
        //     name: uniqueId,
        //     speed: baseSpeed,
        //     team: gitOpts,
        //     appliedLikeSpeed: false,
        //     pic: pic,
        //     shareBalls: 0,
        //     appliedFollowBalls: false,
        //     isKing: false
        //   });
        //   spawn(uniqueId, baseSpeed, gitOpts, pic);
        // }
        let cmd = setPlayerSpeed(uniqueId, speed, pic);
        if (cmd != null) {
            updateCircleSpeed(cmd.name, cmd.speed, cmd.team);
        }
    }
}

/**
 * @param {string} i
 * @param {number} data
 * @return {undefined}
 */
function speedForTeam(i, speed) {
    let their_status = getPlayer(i);
    for (let i = 0; i < players.length; i++) {
        if (players[i].team == their_status.team) {
            let cmd = setPlayerSpeed(players[i].name, speed, players[i].pic);
            if (cmd != null) {
                updateCircleSpeed(cmd.name, cmd.speed, cmd.team);
            }
        }
    }
}

/**
 * @param {string} player
 * @param {number} speed
 * @param {string} callback
 * @return {?}
 */
function setPlayerSpeed(player, speed, callback) {
    let height = 0;
    for (let i = 0; i < players.length; i++) {
        if (players[i].name == player) {
            if (isTeamAlive(players[i].team)) {
                players[i].speed += speed;
                if (players[i].speed > maxSpeed) {
                    height = players[i].speed - maxSpeed;
                    players[i].speed = maxSpeed;
                }
                player = players[i];
                for (let i = 0; i < height / 2; i++) {
                    spawn(player.name, player.speed, player.team, callback);
                }
                break;
            }
        }
    }
    return player;
}

/**
 * @param {?} name
 * @param {boolean} force
 * @param {?} alliscurrent
 * @return {undefined}
 */
function updateCircleSpeed(name, force, alliscurrent) {
    switch (alliscurrent) {
        case 1:
            for (let i = 0; i < team1.length; i++) {
                if (team1[i].name == name) team1[i].force = force;
            }
            break;
        case 2:
            for (let i = 0; i < team2.length; i++) {
                if (team2[i].name == name) team2[i].force = force;
            }
            break;
        case 3:
            for (let i = 0; i < team3.length; i++) {
                if (team3[i].name == name) team3[i].force = force;
            }
            break;
        case 4:
            for (let i = 0; i < team4.length; i++) {
                if (team4[i].name == name) team4[i].force = force;
            }
            break;
        case 5:
            for (let i = 0; i < team5.length; i++) {
                if (team5[i].name == name) team5[i].force = force;
            }
            break;
        default:
            break;
    }
}

/**
 * @param {number} opts
 * @return {?}
 */
function isTeamAlive(opts) {
    let lives = false;
    for (let i = 0; i < teams.length; i++) {
        if (teams[i].id == opts) {
            lives = teams[i].lives;
            break;
        }
    }
    return lives;
}

/**
 * @param {number} frame_id
 * @return {?}
 */
function isTeamSabotaged(frame_id) {
    let sabotaged = false;
    for (let i = 0; i < teams.length; i++) {
        if (teams[i].id == frame_id) {
            sabotaged = teams[i].sabotaged;
            break;
        }
    }
    return sabotaged;
}

/**
 * @param {string} id
 * @param {boolean} connection
 * @param {number} opts
 * @param {string} fn
 * @return {undefined}
 */
function spawn(id, connection, opts, fn) {
    let thisFillColor;
    let isCreditCard_1;
    let charsetBitSize;
    switch (opts) {
        case 1:
            isCreditCard_1 = 275;
            charsetBitSize = 275;
            thisFillColor = team1Color;
            break;
        case 2:
            isCreditCard_1 = 275;
            charsetBitSize = 990;
            thisFillColor = team2Color;
            break;
        case 3:
            isCreditCard_1 = 540;
            charsetBitSize = 640;
            thisFillColor = team3Color;
            break;
        case 4:
            isCreditCard_1 = 810;
            charsetBitSize = 275;
            thisFillColor = team4Color;
            break;
        case 5:
            isCreditCard_1 = 810;
            charsetBitSize = 990;
            thisFillColor = team5Color;
            break;
        default:
            isCreditCard_1 = 275;
            charsetBitSize = 275;
            thisFillColor = team1Color;
            break;
    }
    addCircle(fn, thisFillColor, ballSize, isCreditCard_1, charsetBitSize, id, opts, connection);
}

/**
 * @param {string} value
 * @param {string} color
 * @param {number} size
 * @param {number} x
 * @param {number} y
 * @param {string} id
 * @param {number} args
 * @param {boolean} options
 * @return {undefined}
 */
function addCircle(value, color, size, x, y, id, args, options) {
    if (gameRunning === true) {
        let canvasElement = document.createElement("canvas");
        canvasElement.width = size;
        canvasElement.height = size;
        let ctx = canvasElement.getContext("2d");
        let img = new Image;
        
        img.crossOrigin = "Anonymous";
        img.setAttribute("crossOrigin", "");
        img.src = value || "./img/1.png";
        
        img.onload = () => {
            ctx.drawImage(img, 4, 4, size - 8, size - 8);
            ctx.globalCompositeOperation = "destination-in";
            ctx.beginPath();
            ctx.arc(size / 2, size / 2, (size - 4) / 2, 0, Math.PI * 2);
            ctx.closePath();
            ctx.fill();
            ctx.globalCompositeOperation = "source-over";
            ctx.strokeStyle = color;
            ctx.lineWidth = 4;
            ctx.stroke();
            let body = Bodies.circle(x, y, size / 2, {
                frictionAir: 0,
                friction: 0,
                frictionStatic: 0,
                restitution: 1,
                inertia: Infinity,
                collisionFilter: {
                    group: -args
                },
                render: {
                    sprite: {
                        texture: canvasElement.toDataURL("image/png")
                    }
                }
            });

            switch (args) {
                case 1:
                    team1.push({
                        body: body,
                        running: false,
                        name: id,
                        force: options
                    });
                    break;
                case 2:
                    team2.push({
                        body: body,
                        running: false,
                        name: id,
                        force: options
                    });
                    break;
                case 3:
                    team3.push({
                        body: body,
                        running: false,
                        name: id,
                        force: options
                    });
                    break;
                case 4:
                    team4.push({
                        body: body,
                        running: false,
                        name: id,
                        force: options
                    });
                    break;
                case 5:
                    team5.push({
                        body: body,
                        running: false,
                        name: id,
                        force: options
                    });
                    break;
                default:
                    team1.push({
                        body: body,
                        running: false,
                        name: id,
                        force: options
                    });
                    break;
            }
            let p = getPlayer(id);
            if (p.isKing) {
                Body.scale(body, 1.4, 1.4);
                body.render.sprite.xScale = 1.4;
                body.render.sprite.yScale = 1.4;
            }
            if (isTeamSabotaged(args)) {
                Body.scale(body, 0.8, 0.8);
                body.render.sprite.xScale = 0.8;
                body.render.sprite.yScale = 0.8;
            }
            if (p.isKing && isTeamSabotaged(args)) {
                Body.scale(body, 1, 1);
                body.render.sprite.xScale = 1;
                body.render.sprite.yScale = 1;
            }
            updateCircleSpeed(p.name, p.speed, p.team);
            Composite.add(engine.world, body);
            Body.applyForce(body, {
                x: body.position.x,
                y: body.position.y
            }, randomStartForce(0.05));
        };
    }
}
Matter.Resolver["_restingThresh"] = 0.001;
var gameRunning = false;
let updatepInterval;
let updatepRunning = false;
function start() {
    if (gameRunning === false) {
        teams.forEach((global) => {
            global.lives = true;
            global.sabotaged = false;
        });
        gameRunning = true;
        if (updatepRunning) clearInterval(updatepInterval);
        updatepRunning = true;
        setInterval(() => {
            updatep();
        }, 250);
        countdown(gameSeconds);
    }
}
Events.on(engine, "beforeUpdate", function (canCreateDiscussions) {
    team1.forEach((data) => {
        Body.setAngle(data.body, 0);
        if (isTeamSabotaged(1)) Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force * 0.6));
        else Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force));
    });
    team2.forEach((data) => {
        Body.setAngle(data.body, 0);
        if (isTeamSabotaged(2)) Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force * 0.6));
        else Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force));
    });
    team3.forEach((data) => {
        Body.setAngle(data.body, 0);
        if (isTeamSabotaged(3)) Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force * 0.6));
        else Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force));
    });
    team4.forEach((data) => {
        Body.setAngle(data.body, 0);
        if (isTeamSabotaged(4)) Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force * 0.6));
        else Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force));
    });
    team5.forEach((data) => {
        Body.setAngle(data.body, 0);
        if (isTeamSabotaged(5)) Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force * 0.6));
        else Body.setVelocity(data.body, Vector.mult(Vector.normalise(data.body.velocity), data.force));
    });
});
Events.on(engine, "collisionStart", function (result) {
    if (gameRunning) {
        result.pairs.forEach((data) => {
            if (data.bodyA.label == "Rectangle Body" && isGround(data.bodyA.id) === false) {
                if (data.bodyA.collisionFilter.group != data.bodyB.collisionFilter.group) {
                    if (data.bodyA.collisionFilter.group == -1) {
                        bluep--;
                    } else {
                        if (data.bodyA.collisionFilter.group == -2) {
                            redp--;
                        } else {
                            if (data.bodyA.collisionFilter.group == -3) {
                                yellowp--;
                            } else {
                                if (data.bodyA.collisionFilter.group == -4) {
                                    greenp--;
                                } else {
                                    if (data.bodyA.collisionFilter.group == -5) {
                                        purplep--;
                                    }
                                }
                            }
                        }
                    }
                    if (data.bodyB.label == "Circle Body" && (data.bodyB.collisionFilter.group == -2 || data.bodyB.collisionFilter.group == -3 || data.bodyB.collisionFilter.group == -4 || data.bodyB.collisionFilter.group == -5) && data.bodyA.position.x >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyA.position.x <= 31 + blockWidth / 2 + 13 * blockWidth + 13 * borderSize && data.bodyA.position.y >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyA.position.y <= 31 +
                        blockWidth / 2 + 13 * blockWidth + 13 * borderSize) {
                        killTeam(1, -data.bodyB.collisionFilter.group);
                    }
                    if (data.bodyB.label == "Circle Body" && (data.bodyB.collisionFilter.group == -1 || data.bodyB.collisionFilter.group == -3 || data.bodyB.collisionFilter.group == -4 || data.bodyB.collisionFilter.group == -5) && data.bodyA.position.x >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyA.position.x <= 31 + blockWidth / 2 + 13 * blockWidth + 13 * borderSize && data.bodyA.position.y >= 31 + blockWidth / 2 + 46 * blockWidth + 46 * borderSize && data.bodyA.position.y <= 31 +
                        blockWidth / 2 + 46 * blockWidth + 49 * borderSize) {
                        killTeam(2, -data.bodyB.collisionFilter.group);
                    }
                    if (data.bodyB.label == "Circle Body" && (data.bodyB.collisionFilter.group == -1 || data.bodyB.collisionFilter.group == -2 || data.bodyB.collisionFilter.group == -4 || data.bodyB.collisionFilter.group == -5) && data.bodyA.position.x >= 31 + blockWidth / 2 + 23 * blockWidth + 23 * borderSize && data.bodyA.position.x <= 31 + blockWidth / 2 + 26 * blockWidth + 26 * borderSize && data.bodyA.position.y >= 31 + blockWidth / 2 + 28 * blockWidth + 28 * borderSize && data.bodyA.position.y <= 31 +
                        blockWidth / 2 + 31 * blockWidth + 31 * borderSize) {
                        killTeam(3, -data.bodyB.collisionFilter.group);
                    }
                    if (data.bodyB.label == "Circle Body" && (data.bodyB.collisionFilter.group == -1 || data.bodyB.collisionFilter.group == -2 || data.bodyB.collisionFilter.group == -3 || data.bodyB.collisionFilter.group == -5) && data.bodyA.position.x >= 31 + blockWidth / 2 + 36 * blockWidth + 36 * borderSize && data.bodyA.position.x <= 31 + blockWidth / 2 + 39 * blockWidth + 39 * borderSize && data.bodyA.position.y >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyA.position.y <= 31 +
                        blockWidth / 2 + 13 * blockWidth + 13 * borderSize) {
                        killTeam(4, -data.bodyB.collisionFilter.group);
                    }
                    if (data.bodyB.label == "Circle Body" && (data.bodyB.collisionFilter.group == -1 || data.bodyB.collisionFilter.group == -2 || data.bodyB.collisionFilter.group == -3 || data.bodyB.collisionFilter.group == -4) && data.bodyA.position.x >= 31 + blockWidth / 2 + 36 * blockWidth + 36 * borderSize && data.bodyA.position.x <= 31 + blockWidth / 2 + 39 * blockWidth + 39 * borderSize && data.bodyA.position.y >= 31 + blockWidth / 2 + 46 * blockWidth + 46 * borderSize && data.bodyA.position.y <= 31 +
                        blockWidth / 2 + 49 * blockWidth + 49 * borderSize) {
                        killTeam(5, -data.bodyB.collisionFilter.group);
                    }
                    data.bodyA.collisionFilter.group = data.bodyB.collisionFilter.group;
                    if (data.bodyA.collisionFilter.group == -1) {
                        bluep++;
                        data.bodyA.render.fillStyle = team1Bg;
                    } else {
                        if (data.bodyA.collisionFilter.group == -2) {
                            redp++;
                            data.bodyA.render.fillStyle = team2Bg;
                        } else {
                            if (data.bodyA.collisionFilter.group == -3) {
                                yellowp++;
                                data.bodyA.render.fillStyle = team3Bg;
                            } else {
                                if (data.bodyA.collisionFilter.group == -4) {
                                    greenp++;
                                    data.bodyA.render.fillStyle = team4Bg;
                                } else {
                                    if (data.bodyA.collisionFilter.group == -5) {
                                        purplep++;
                                        data.bodyA.render.fillStyle = team5Bg;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (data.bodyB.label == "Rectangle Body" && isGround(data.bodyB.id) === false) {
                    if (data.bodyB.collisionFilter.group != data.bodyA.collisionFilter.group) {
                        if (data.bodyB.collisionFilter.group == -1) {
                            bluep--;
                        } else {
                            if (data.bodyB.collisionFilter.group == -2) {
                                redp--;
                            } else {
                                if (data.bodyB.collisionFilter.group == -3) {
                                    yellowp--;
                                } else {
                                    if (data.bodyB.collisionFilter.group == -4) {
                                        greenp--;
                                    } else {
                                        if (data.bodyB.collisionFilter.group == -5) {
                                            purplep--;
                                        }
                                    }
                                }
                            }
                        }
                        if (data.bodyA.label == "Circle Body" && (data.bodyA.collisionFilter.group == -2 || data.bodyA.collisionFilter.group == -3 || data.bodyA.collisionFilter.group == -4 || data.bodyA.collisionFilter.group == -5) && data.bodyB.position.x >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyB.position.x <= 31 + blockWidth / 2 + 13 * blockWidth + 13 * borderSize && data.bodyB.position.y >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyB.position.y <= 31 +
                            blockWidth / 2 + 13 * blockWidth + 13 * borderSize) {
                            killTeam(1, -data.bodyB.collisionFilter.group);
                        }
                        if (data.bodyA.label == "Circle Body" && (data.bodyA.collisionFilter.group == -1 || data.bodyA.collisionFilter.group == -3 || data.bodyA.collisionFilter.group == -4 || data.bodyA.collisionFilter.group == -5) && data.bodyB.position.x >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyB.position.x <= 31 + blockWidth / 2 + 13 * blockWidth + 13 * borderSize && data.bodyB.position.y >= 31 + blockWidth / 2 + 46 * blockWidth + 46 * borderSize && data.bodyB.position.y <= 31 +
                            blockWidth / 2 + 46 * blockWidth + 49 * borderSize) {
                            killTeam(2, -data.bodyB.collisionFilter.group);
                        }
                        if (data.bodyA.label == "Circle Body" && (data.bodyA.collisionFilter.group == -1 || data.bodyA.collisionFilter.group == -2 || data.bodyA.collisionFilter.group == -4 || data.bodyA.collisionFilter.group == -5) && data.bodyB.position.x >= 31 + blockWidth / 2 + 23 * blockWidth + 23 * borderSize && data.bodyB.position.x <= 31 + blockWidth / 2 + 26 * blockWidth + 26 * borderSize && data.bodyB.position.y >= 31 + blockWidth / 2 + 28 * blockWidth + 28 * borderSize && data.bodyB.position.y <= 31 +
                            blockWidth / 2 + 31 * blockWidth + 31 * borderSize) {
                            killTeam(3, -data.bodyB.collisionFilter.group);
                        }
                        if (data.bodyA.label == "Circle Body" && (data.bodyA.collisionFilter.group == -1 || data.bodyA.collisionFilter.group == -2 || data.bodyA.collisionFilter.group == -3 || data.bodyA.collisionFilter.group == -5) && data.bodyB.position.x >= 31 + blockWidth / 2 + 36 * blockWidth + 36 * borderSize && data.bodyB.position.x <= 31 + blockWidth / 2 + 39 * blockWidth + 39 * borderSize && data.bodyB.position.y >= 31 + blockWidth / 2 + 10 * blockWidth + 10 * borderSize && data.bodyB.position.y <= 31 +
                            blockWidth / 2 + 13 * blockWidth + 13 * borderSize) {
                            killTeam(4, -data.bodyB.collisionFilter.group);
                        }
                        if (data.bodyA.label == "Circle Body" && (data.bodyA.collisionFilter.group == -1 || data.bodyA.collisionFilter.group == -2 || data.bodyA.collisionFilter.group == -3 || data.bodyA.collisionFilter.group == -4) && data.bodyB.position.x >= 31 + blockWidth / 2 + 36 * blockWidth + 36 * borderSize && data.bodyB.position.x <= 31 + blockWidth / 2 + 39 * blockWidth + 39 * borderSize && data.bodyB.position.y >= 31 + blockWidth / 2 + 46 * blockWidth + 46 * borderSize && data.bodyB.position.y <= 31 +
                            blockWidth / 2 + 49 * blockWidth + 49 * borderSize) {
                            killTeam(5, -data.bodyB.collisionFilter.group);
                        }
                        data.bodyB.collisionFilter.group = data.bodyA.collisionFilter.group;
                        if (data.bodyB.collisionFilter.group == -1) {
                            bluep++;
                            data.bodyB.render.fillStyle = team1Bg;
                        } else {
                            if (data.bodyB.collisionFilter.group == -2) {
                                redp++;
                                data.bodyB.render.fillStyle = team2Bg;
                            } else {
                                if (data.bodyB.collisionFilter.group == -3) {
                                    yellowp++;
                                    data.bodyB.render.fillStyle = team3Bg;
                                } else {
                                    if (data.bodyB.collisionFilter.group == -4) {
                                        greenp++;
                                        data.bodyB.render.fillStyle = team4Bg;
                                    } else {
                                        if (data.bodyB.collisionFilter.group == -5) {
                                            purplep++;
                                            data.bodyB.render.fillStyle = team5Bg;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
    }
});

/**
 * @param {number} n
 * @param {number} game
 * @return {undefined}
 */
function killTeam(n, game) {
    switch (n) {
        case 1:
            setTeamLives(1, false);
            team1.forEach((object) => {
                Composite.remove(engine.world, object.body);
            });
            team1 = [];
            document.getElementById("team1Castle").style.display = "none";
            break;
        case 2:
            setTeamLives(2, false);
            team2.forEach((object) => {
                Composite.remove(engine.world, object.body);
            });
            team2 = [];
            document.getElementById("team2Castle").style.display = "none";
            break;
        case 3:
            setTeamLives(3, false);
            team3.forEach((object) => {
                Composite.remove(engine.world, object.body);
                killTeam;
            });
            team3 = [];
            document.getElementById("team3Castle").style.display = "none";
            break;
        case 4:
            setTeamLives(4, false);
            team4.forEach((object) => {
                Composite.remove(engine.world, object.body);
            });
            team4 = [];
            document.getElementById("team4Castle").style.display = "none";
            break;
        case 5:
            setTeamLives(5, false);
            team5.forEach((object) => {
                Composite.remove(engine.world, object.body);
            });
            team5 = [];
            document.getElementById("team5Castle").style.display = "none";
            break;
        default:
            setTeamLives(1, false);
            team1.forEach((object) => {
                Composite.remove(engine.world, object.body);
            });
            team1 = [];
            document.getElementById("team1Castle").style.display = "none";
            break;
    }
    if (countDeathTeams() == 4) {
        gameOver(game);
    }
}

/**
 * @param {number} frame_id
 * @param {string} html
 * @return {undefined}
 */
function setTeamLives(frame_id, html) {
    for (let i = 0; i < teams.length; i++) {
        if (teams[i].id == frame_id) {
            teams[i].lives = html;
        }
    }
}

/**
 * @param {number} source
 * @param {boolean} overrideConstructor
 * @return {undefined}
 */
function setTeamSabotaged(source, overrideConstructor) {
    for (let i = 0; i < teams.length; i++) {
        if (teams[i].id == source) {
            teams[i].sabotaged = overrideConstructor;
        }
    }
}

function countDeathTeams() {
    let deaths = 0;
    for (let i = 0; i < teams.length; i++) {
        if (teams[i].lives == false) {
            deaths++;
        }
    }
    return deaths;
}

let winningP = 80;
let pointsList = [
    {
        id: 1,
        tag: "Blue",
        points: 0
    },
    {
        id: 2,
        tag: "Red",
        points: 0
    },
    {
        id: 3,
        tag: "Yellow",
        points: 0
    },
    {
        id: 4,
        tag: "Green",
        points: 0
    },
    {
        id: 5,
        tag: "Purple",
        points: 0
    }
];
let sortedPointsList = [];

function updatep() {
    if (gameRunning) {
        
        pointsList[0].points = (bluep / totalPoints * 100).toFixed(2);
        pointsList[1].points = (redp / totalPoints * 100).toFixed(2);
        pointsList[2].points = (yellowp / totalPoints * 100).toFixed(2);
        pointsList[3].points = (greenp / totalPoints * 100).toFixed(2);
        pointsList[4].points = (purplep / totalPoints * 100).toFixed(2);
        let coverage = 0;

        for (let i = 0; i < pointsList.length; i++) {
            const point = pointsList[i];
            document.getElementById(point.tag.toLowerCase() + "pr").value = point.points;
            document.getElementById(point.tag.toLowerCase() + "prTag").innerHTML = point.tag + ": " + point.points + "%";
            document.getElementById(point.tag.toLowerCase() + "Graphic").style.width = point.points + "%";
            coverage = coverage + parseFloat(point.points);
            if(point.points > 5) {
                document.getElementById(point.tag.toLowerCase() + "_percentage").innerHTML = point.points > 8 ? `${point.points}%` : `${Number(point.points).toFixed(0)}%`;
            } else {
                document.getElementById(point.tag.toLowerCase() + "_percentage").innerHTML = "";
            };
        }
        
        // document.getElementById("overlayGraphic").style.width = coverage + "%";
        sortedPointsList = pointsList.slice().sort((a, b) => {
            return b.points - a.points;
        });
        for (let i = 0; i < sortedPointsList.length; i++) {
            document.getElementById(sortedPointsList[i].tag.toLowerCase() + "prc").style.order = "" + i;
        }
    }
}

function isGround(obj) {
    let ground = false;
    return grounds.forEach((window) => {
        if (obj == window.id) {
            ground = true;
        }
    }), ground;
}

let x;
let timerRunning = false;

function countdown(clockNumbers) {
    let endDate = new Date;
    endDate.setSeconds(endDate.getSeconds() + clockNumbers + 1);
    let endTimestamp = endDate.getTime();
    timerRunning = true;

    x = setInterval(function () {
        let actualTimestamp = (new Date).getTime();
        let difTimestamp = endTimestamp - actualTimestamp;
        let timeSeconds = difTimestamp / 1000;

        const minutes = Math.floor((timeSeconds) / 60);
        const seconds = Math.floor(((timeSeconds) / 60 - minutes) * 60);

        document.getElementById("countdown").innerHTML = `${minutes}:${seconds < 10 ? "0" + seconds : seconds}`;
        if (difTimestamp < 0) {
            if (timerRunning = true) clearInterval(x);
            timerRunning = false;
            document.getElementById("countdown").innerHTML = "比赛结束";
            gameOver(null);
        }
    }, 100);
}

/**
 * @param {number} type
 * @return {undefined}
 */
function gameOver(type) {
    if (gameRunning) {
        gameRunning = false;
        document.getElementById("kingContainer").style.opacity = 0;
        for (let i = 0; i < sabotageTimeouts.length; i++) {
            if (sabotageTimeouts[i] != null) {
                clearInterval(sabotageTimeouts[i]);
                sabotageTimeouts[i] = null;
            }
        }
        if (updatepRunning) {
            clearInterval(updatepInterval);
            updatepRunning = false;
        }
        if (type == null) {
            sortedPointsList = pointsList.slice().sort((a, b) => {
                return b.points - a.points;
            });
            if (sortedPointsList[0].tag == "Blue") {
                document.getElementById("gameOverWinnerText").innerHTML = "蓝色赢家";
                document.getElementById("gameOverWinnerText").style.color = team1Bg;
            } else {
                if (sortedPointsList[0].tag == "Red") {
                    document.getElementById("gameOverWinnerText").innerHTML = "红色的胜利";
                    document.getElementById("gameOverWinnerText").style.color = team2Bg;
                } else {
                    if (sortedPointsList[0].tag == "Yellow") {
                        document.getElementById("gameOverWinnerText").innerHTML = "黄色胜出";
                        document.getElementById("gameOverWinnerText").style.color = team3Bg;
                    } else {
                        if (sortedPointsList[0].tag == "Green") {
                            document.getElementById("gameOverWinnerText").innerHTML = "绿色赢家";
                            document.getElementById("gameOverWinnerText").style.color = team4Bg;
                        } else {
                            document.getElementById("gameOverWinnerText").innerHTML = "紫色胜出";
                            document.getElementById("gameOverWinnerText").style.color = team5Bg;
                        }
                    }
                }
            }
        } else {
            if (type == 1) {
                document.getElementById("gameOverWinnerText").innerHTML = "蓝色赢家";
                document.getElementById("gameOverWinnerText").style.color = team1Bg;
            } else {
                if (type == 2) {
                    document.getElementById("gameOverWinnerText").innerHTML = "红色的胜利";
                    document.getElementById("gameOverWinnerText").style.color = team2Bg;
                } else {
                    if (type == 3) {
                        document.getElementById("gameOverWinnerText").innerHTML = "黄色胜出";
                        document.getElementById("gameOverWinnerText").style.color = team3Bg;
                    } else {
                        if (type == 4) {
                            document.getElementById("gameOverWinnerText").innerHTML = "绿色赢家";
                            document.getElementById("gameOverWinnerText").style.color = team4Bg;
                        } else {
                            document.getElementById("gameOverWinnerText").innerHTML = "紫色胜出";
                            document.getElementById("gameOverWinnerText").style.color = team5Bg;
                        }
                    }
                }
            }
        }
        
        document.getElementById("gameOverPanel").style.visibility = "visible";
        document.getElementById("gameOverPanel").style.opacity = "1";

        if (timerRunning = true) {
            clearInterval(x);
            timerRunning = false;
        }
        setTimeout(() => {
            document.getElementById("gameOverPanel").style.visibility = "hidden";
            document.getElementById("gameOverPanel").style.opacity = "0";
            initializeWorld();
            start();
        }, 2500);
    }
}

/**
 * @param {number} partKeys
 * @return {?}
 */
function randomStartForce(partKeys) {
    let range = rng(0, 3);
    let stepValue = rng(1, partKeys * 100);
    stepValue = stepValue / 100;
    switch (range) {
        case 0:
            return {
                x: stepValue,
                y: stepValue
            };
            break;
        case 1:
            return {
                x: -stepValue,
                y: stepValue
            };
            break;
        case 2:
            return {
                x: -stepValue,
                y: -stepValue
            };
            break;
        case 3:
            return {
                x: stepValue,
                y: -stepValue
            };
            break;
        default:
            return {
                x: stepValue,
                y: -stepValue
            };
            break;
    }
}

/**
 * @param {number} size
 * @param {number} state
 * @return {?}
 */
function rng(size, state) {
    return Math.floor(Math.random() * (state - size + 1)) + size;
}

initializeWorld();

/**
 * @param {string} i
 * @param {string} url
 * @return {undefined}
 */
function king(i, url) {
    if (gameRunning) {
        if (userPlaying(i) === false) {
            let gitOpts = rng(1, 5);
            for (; isTeamAlive(gitOpts) == false;) {
                gitOpts = rng(1, 5);
            }
            players.push({
                name: i,
                speed: baseSpeed,
                team: gitOpts,
                appliedLikeSpeed: false,
                pic: url,
                shareBalls: 0,
                appliedFollowBalls: false,
                isKing: false
            });
            spawn(i, baseSpeed, gitOpts, url);
        }
        let p = getPlayer(i);
        p.isKing = true;
        if (p != null) {
            switch (p.team) {
                case 1:
                    team1.forEach((data) => {
                        if (data.name == i) {
                            Body.scale(data.body, 1.4, 1.4);
                            data.body.render.sprite.xScale = 1.4;
                            data.body.render.sprite.yScale = 1.4;
                        }
                    });
                    break;
                case 2:
                    team2.forEach((data) => {
                        if (data.name == i) {
                            Body.scale(data.body, 1.4, 1.4);
                            data.body.render.sprite.xScale = 1.4;
                            data.body.render.sprite.yScale = 1.4;
                        }
                    });
                    break;
                case 3:
                    team3.forEach((data) => {
                        if (data.name == i) {
                            Body.scale(data.body, 1.4, 1.4);
                            data.body.render.sprite.xScale = 1.4;
                            data.body.render.sprite.yScale = 1.4;
                        }
                    });
                    break;
                case 4:
                    team4.forEach((data) => {
                        if (data.name == i) {
                            Body.scale(data.body, 1.4, 1.4);
                            data.body.render.sprite.xScale = 1.4;
                            data.body.render.sprite.yScale = 1.4;
                        }
                    });
                    break;
                case 5:
                    team5.forEach((data) => {
                        if (data.name == i) {
                            Body.scale(data.body, 1.4, 1.4);
                            data.body.render.sprite.xScale = 1.4;
                            data.body.render.sprite.yScale = 1.4;
                        }
                    });
                    break;
                default:
                    team1.forEach((data) => {
                        if (data.name == i) {
                            Body.scale(data.body, 1.4, 1.4);
                            data.body.render.sprite.xScale = 1.4;
                            data.body.render.sprite.yScale = 1.4;
                        }
                    });
                    break;
            }
            document.getElementById("crownUser").src = url;
            document.getElementById("kingContainer").style.opacity = 1;
            setTimeout(() => {
                party.confetti(document.getElementById("crown"), {
                    count: party.variation.range(40, 60),
                    size: party.variation.skew(2, 0.2)
                });
            }, 1000);
            setTimeout(() => {
                party.confetti(document.getElementById("crown"), {
                    count: party.variation.range(40, 60),
                    size: party.variation.skew(2, 0.2)
                });
            }, 2000);
        }
    }
};